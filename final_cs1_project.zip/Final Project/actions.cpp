#include "actions.hpp"
#include <iostream>
#include <string>
#include <iomanip>
#include "validation.hpp"

void addRecipe(vector<vector<double>>& quantity, vector<vector<string>>& ingredients, ifstream& allRecipes, ofstream& allQuantities, ofstream& allIngredients)
{
	static int recipeNum = 0;
	allRecipes.open("recipeNames.txt", ios::app);
	// if no recipe names in recipe names file, no recipes exist so we are on recipe number one
	if (allRecipes.is_open())
	{
		allRecipes.seekg(0, ios::end);
		if (allRecipes.tellg() == 0)
		{
			recipeNum = 1;
			cout << "currently on recipe number "  << recipeNum << endl; // debugging for myself
		}
		else
		{
			allRecipes.seekg(0);
			string line;
			while (getline(allRecipes, line))
			{
				recipeNum++;
			}
			cout << "currently on recipe number "  << ++recipeNum << endl; // debugging for myself
		}
	}
	allRecipes.close();
	string recipeName;
	string ingQuantity = "1";
	string ingredient;
	vector<string> steps;
	string line;

	vector<double> recipeQuantity;
	vector<string> recipeIngredients;
	cout << "\n❗️disclaimer❗️ this book is for household use mainly, so please keep in mind the serving size of this recipe will be 1. \nIf you want to use this recipe for a different serving size later, please use that option from the menu\n\n";

	cout << "What is the name of your recipe?\n";
	cin.ignore();
	getline(cin, recipeName);
	allRecipes.open("recipeNames.txt", ios::app);

	if (allRecipes.is_open())
	{
		bool unique = false;
		while (!unique)
		{
			allRecipes.clear();
			allRecipes.seekg(0, ios::beg);
			unique = true;

			// ask for recipe name while user's input is equal to any of the names in the recipe names file
			while (getline(allRecipes, line))
			{
				if (line == recipeName)
				{
					// make sure user isn't writing a recipe with the same name
					cout << "Recipe name already exists! Enter a different name:\n";
					getline(cin, recipeName);
					unique = false;
					break;
				}
			}
		}
	}
	else
	{
		cout << "Main file failed to open. Rerouting to menu now...\n";
		allRecipes.close();
		return;
	}
	// add recipe name to recipeNames file
	allRecipes.close();
	ofstream recipes;
	recipes.open("recipeNames.txt", ios::app);
	recipes << recipeName << endl;
	recipes.close();

	Times recipeTimes;
	double prep;
	double cook;
	// save prep and cook time to structure
	while (true) {
		cout << "Enter the time it would take to prepare this recipe (as a number in minutes): ";
		cin >> prep;
		if (cin.fail()) {
			cin.clear();
			cin.ignore(4096, '\n');
		}
		else {
			recipeTimes.prepTime = prep;
			break;
		}
	}
	while (true) {
		cout << "\nEnter the time it would take to actually cook this recipe (as a number in minutes): ";
		cin >> cook;
		if (cin.fail()) {
			cin.clear();
			cin.ignore(4096, '\n');
		}
		else {
			recipeTimes.cookTime = cook;
			break;
		}
	}

	double ingQuantityNum = stod(ingQuantity);
	cin.ignore();
	// alternate between asking the user for the amount of the ingredient (with validation) and the actual ingredient
	// quantities and ingredients are pushed back to local vectors to hold these values for this recipe
	while (ingQuantityNum!=0)
	{
		cout << "\nEnter just the amount/quantity of the ingredient as a number(ex. 3.5). \nIf you have no more ingredients in this recipe, type 0\n";
		bool validDouble = false;
		while (validDouble == false)
		{
			getline(cin, ingQuantity);

			validDouble = isDouble(ingQuantity);
		}
		ingQuantityNum = stod(ingQuantity);
		if (ingQuantityNum == 0)
		{
			break;
		}
		recipeQuantity.push_back(ingQuantityNum);

		cout << "\nEnter the measurement of the quantity you just entered (only limited to teaspoons, tablespoons, and cups). Then, type the name of the ingredient (ex. cups flour)\n";
		getline(cin, ingredient);
		recipeIngredients.push_back(ingredient);
	}
	// ask user to enter recipe steps , push back to steps vector for this recipe
	string step;
	do
	{
		cout << "\nEnter your steps/directions (ex. Sift the flour). If you have no more steps, type done\n";
		getline(cin, step);
		if (step == "done")
		{
			break;
		}
		steps.push_back(step);
	} while (!(step == "done"));

	ofstream recipeFile;
	recipeFile.open (recipeName + ".txt");

	// write all information to this recipe's file nice and pretty :P
	recipeFile << "Recipe " << recipeNum << ": " << recipeName << endl;
	recipeFile << "\nIngredients:\n";
	for (unsigned i = 0; i < recipeQuantity.size(); i++)
	{
		for (unsigned j = 0; j < 1; j++)
		{
			recipeFile << setw(7) << recipeQuantity.at(i) << "| ";
			recipeFile << recipeIngredients.at(i) << endl;
		}
		recipeFile << "------------------------------" << endl;
	}
	recipeFile << "\nAdditional Details:\n";
	recipeFile << "\tPrep time for this recipe is " << recipeTimes.prepTime << " minutes\n";
	recipeFile << "\tCook time for this recipe is " << recipeTimes.cookTime << " minutes\n";

	recipeFile << "\nSteps:\n";
	for (unsigned i = 0; i < steps.size(); i++)
	{
		recipeFile << i + 1 << ". " << steps.at(i) << endl;
	}
	recipeFile.close();

	// add this recipe's values to the 2D vectors for all the recipe's quantities and ingredients
	quantity.push_back(recipeQuantity);
	ingredients.push_back(recipeIngredients);

	// write values to quantities file and ingredients file to save it for later/next runs
	allQuantities.open("quantities.txt", ios::app);

	if (!allQuantities.is_open())
	{
		cout << "Unable to open file." << endl;
	}
	else
	{
		for (double elem : quantity.at(recipeNum - 1))
		{
		    allQuantities << elem;
		    if (&elem != &quantity.at(recipeNum - 1).back())
		    {
		        allQuantities << ",";
		    }
		}
		allQuantities << endl;
	}
	allQuantities.close();

	allIngredients.open("ingredients.txt", ios::app);

	if (!allIngredients.is_open())
	{
		cout << "Unable to open file." << endl;
	}
	else
	{
		for (string elem : ingredients.at(recipeNum-1))
		{
			allIngredients << elem << ",";
		}
		allIngredients << endl;
	}
	allIngredients.close();
}


void conversion()
{
	string ogMeas;
	string newMeas;
	string ogVal;
	double newVal;
	cout << "Here, you can convert some measurements! This calculator is limited to teaspoons, tablespoons, and cups. You can use decimals.\n"; // can add some fancy formatting thing from some library
	cin.ignore();
	// ask for original measurement
	do
	{
		cout << "\nChoose the measurement you want to convert (tbsp, tsp, cup): ";
		getline(cin, ogMeas);
	} while (!(ogMeas == "tbsp" || ogMeas == "tsp" || ogMeas == "cup"));

	// ask for how much should be converted
	cout << "How much of this measurement do you want to convert? (ex. 3.5): ";
	bool validDouble = false;
	while (validDouble == false)
	{
		getline(cin, ogVal);
		validDouble = isDouble(ogVal);
	}
	double ogValNum = stod(ogVal);
	// ask for measurement to convert original measurement to
	do
	{
		cout << "\nChoose the measurement you want to convert to (tbsp, tsp, cup): ";
		getline(cin, newMeas);
	} while (!(newMeas == "tbsp" || newMeas == "tsp" || newMeas == "cup" || newMeas == ogMeas));

	// do math and print
	if (ogMeas == "tbsp" && newMeas == "tsp")
	{
		newVal = ogValNum * 3;
		cout << ogVal << " tbsp is " << newVal << " tsp\n";
	}
	else if (ogMeas == "tsp" && newMeas == "tbsp")
	{
		newVal = ogValNum / 3;
		cout << ogVal << " tsp is " << newVal << " tbsp\n";
	}
	else if (ogMeas == "tbsp" && newMeas == "cup")
	{
		newVal = ogValNum / 16;
		cout << ogVal << " tbsp is " << newVal << " cups\n";
	}
	else if (ogMeas == "cup" && newMeas == "tbsp")
	{
		newVal = ogValNum * 16;
		cout << ogVal << " cups is " << newVal << " tbsp\n";
	}
	else if (ogMeas == "tsp" && newMeas == "cup")
	{
		newVal = ogValNum / 48;
		cout << ogVal << " tsp is " << newVal << " cups\n";
	}
	else if (ogMeas == "cup" && newMeas == "tsp")
	{
		newVal = ogValNum * 48;
		cout << ogVal << " cups is " << newVal << " tsp\n";
	}
}

// pheewwww time to scale serving size..
void scaleServing(const vector<vector<double>>& quantity, const vector<vector<string>>& ingredients, ifstream& allRecipes)
{
	allRecipes.open("recipeNames.txt");
	vector<string> recipes;
	vector<vector<double>> newQuan;
	newQuan = quantity;
	string line;
	string recipeChoice;
	int numRecipes = 0;
	string userServingSize;
	cin.ignore();

	// if there are no quantities or ingredients, send user back
	if (newQuan.size() == 0 || ingredients.size() == 0)
	{
		cout << "Hmm, no ingredients or steps were saved. Please enter a recipe to save these things. Sending you back to the homepage...\n";
		return;
	}
	else
	{
		// read recipe names, process to recipe names vector
		if (allRecipes.is_open())
		{
			allRecipes.seekg(0);
			while (getline(allRecipes, line))
			{
				recipes.push_back(line);
			}
		}
		allRecipes.close();
		cout << "Here are the recipes you can choose to scale the serving/portion size of. Keep in mind, each recipe is currently equivalent to 1 portion/serving: \n";

		for (string recipe : recipes)
		{
			cout << '\t' << "🥧 " << recipe << endl;
		}

		// get user's recipe choice & validate
		bool valid = false;
		while (valid == false)
		{
			cout << "Which recipe would you like to scale the serving size of? ";
			getline(cin, recipeChoice);
			valid = validRecipe(recipeChoice, allRecipes);
		}

		int i = 0;
		while (i < recipes.size() && recipes.at(i) != recipeChoice)   {
			numRecipes++;
			i++;
		}
		cout << "How many portions/servings do you want to scale this recipe to? Keep in mind, each recipe is currently equivalent to 1 portion/serving (ex. 2): ";

		// make sure user's input is an int
		bool validInt = false;
		while (validInt == false)
		{
			getline(cin, userServingSize);
			validInt = isInt(userServingSize);
		}
		double userServingSizeNum = stoi(userServingSize);
		cout << endl;
		// multiply every quantity by user's serving size
		for (double& quantity : newQuan.at(numRecipes)) {
			quantity = quantity * userServingSizeNum;
		}

		// print the ingredients and their amounts in a pretty table
		for (unsigned i = 0; i < newQuan.at(numRecipes).size(); i++)
		{
			cout << newQuan.at(numRecipes).at(i) << "| ";
			cout << setw(5) << ingredients.at(numRecipes).at(i) << endl;
			cout << "------------------------------" << endl;
		}

		// find "additional" in recipe file and print out everything after that
		string allContent = "";
		string str = "Additional";
		ifstream OGRecipeFile;
		OGRecipeFile.open(recipeChoice + ".txt");
		if (OGRecipeFile.is_open())
		{
			OGRecipeFile.seekg(0);
			while (getline(OGRecipeFile, line))
			{
				allContent = allContent + line + "\n";
			}
		}

		size_t found = allContent.find(str);
		if (found != string::npos) {
			string steps = allContent.substr(found);
			cout << endl << steps << endl;
		} else {
			cout << "Rest of recipe not found." << endl;
		}
	}
}
