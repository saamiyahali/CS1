#include "validation.hpp"
#include <iostream>
#include <fstream>
#include "display.hpp"

void displayRecipe(ifstream& allRecipes)
{
  string recipeName;
  vector<string> recipes;
  string line;
  allRecipes.open("recipeNames.txt");
  cin.ignore();

  // if the file for recipe names is empty
  if (allRecipes.peek() == ifstream::traits_type::eof())
  {
	  cout << "there's no recipes yet :( going back to the menu...\n";
	  return;
  }
  else
  {
    if (allRecipes.is_open())
    {
      while (getline(allRecipes, line))
      {
        recipes.push_back(line); // save every name from the recipe names file to a vector
      }
    }
    allRecipes.close();
    cout << "Here are the current recipes: \n";
    for (string recipe : recipes)
    {
      cout << endl << '\t' << "🥧 " << recipe << endl; // print out all existing recipe names
    }

	bool valid = false;
	// recipe name validation to make sure it actually exists
	while (valid == false)
	{
		cout << "Enter the name of the recipe you would like to display: ";
		getline(cin, recipeName);
		valid = validRecipe(recipeName, allRecipes);
	}

    ifstream outfile(recipeName + ".txt");
    // print out contents of the recipe
    if (outfile.is_open())
    {
      cout << endl << outfile.rdbuf();
    }
  }
  allRecipes.close();
}

void randRecipe(ifstream& allRecipes)
{
  srand(time(0));
  allRecipes.open("recipeNames.txt");
  vector<string> recipes;
  string line;

  if (allRecipes.peek() == ifstream::traits_type::eof())
  {
	  cout << "there's no recipes yet :( going back to the menu...\n";
	  return;
  }
  // save all recipe names to vector
  if (allRecipes.is_open())
  {
    while (getline(allRecipes, line))
    {
      recipes.push_back(line);
    }
  }
  // randomly generate an index and print whatever recipe is at that index
  int randomIndex = rand() % recipes.size();
  string randRecipe = recipes.at(randomIndex);

  ifstream randRecipeFile(randRecipe + ".txt");

  if (randRecipeFile.is_open())
  {
    randRecipeFile.seekg(0);
    cout << randRecipeFile.rdbuf();
  }
}
