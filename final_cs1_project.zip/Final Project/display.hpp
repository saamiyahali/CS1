#include <vector>
#include <fstream>

using namespace std;

/*
 * Desc: display a recipe currently existing in the cookbook
 * Input: input file for recipe names file
 * Output: N/A
 */
void displayRecipe(ifstream&);

/*
 * Desc: randomly display a recipe currently existing in the cookbook
 * Input: input file for recipe names file
 * Output: N/A
 */
void randRecipe(ifstream&);

