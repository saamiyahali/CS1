#include <string>
#include <fstream>

using namespace std;
/*
 * Desc: checks if the recipe name that the user inputs is actually a recipe that exists
 * Input: user's recipe name, input file for recipe names file, bool
 * Output: true if recipe exists, false if not
 */
bool validRecipe(string , ifstream&, bool valid = false);

/*
 * Desc: make sure the user's input is an integer
 * Input: hopefully a number, as a string
 * Output: true if input is an integer, false if not
 */
bool isInt(string);

/*
 * Desc: make sure the user's input is a double
 * Input: hopefully a decimal/integer, as a string
 * Output: true if input is a double, false if not
 */
bool isDouble(string);
