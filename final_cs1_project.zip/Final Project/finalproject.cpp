#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <ctime>
#include <cstdlib>
#include <fstream>
#include <cstring>
#include <iomanip>
#include "actions.hpp"
#include "display.hpp"

using namespace std;
/*
 * Desc: starting point of the program, has the menu which calls functions based on the user's option
 * Input: N/A
 * Output: an integer that signals the exit code to the operating system (OS)
 */
int main() {
	int userChoice;
	bool isValidInput;
	vector<vector<double>> quantity;
	vector<vector<string>> ingredients;

	ifstream allRecipes;

	ifstream allQuantities;
	ifstream allIngredients;

	// open all quantities file. save each comma separated value to an element in a row of the quantities 2D vector
	allQuantities.open("quantities.txt", ios::app);
	allQuantities.seekg(0, ios::beg);

	string line;
	while (getline(allQuantities, line))
	{
		vector<double> row;
		string value = "";
		for (char c : line)
		{
			if (c == ',')
			{
				if (!value.empty())
				{
					row.push_back(stod(value));
				}
				value = "";
			}
			else
			{
				value += c;
			}
		}
		if (!value.empty())
		{
			row.push_back(stod(value));
		}
		quantity.push_back(row);
	}
	allQuantities.close();

	// open all ingredients file. save each comma separated value to an element in a row of the ingredients 2D vector
	allIngredients.open("ingredients.txt", ios::app);
	allIngredients.seekg(0, ios::beg);

	line = "";
	while (getline(allIngredients, line))
	{
		vector<string> row;
		string value = "";
		for (char c : line)
		{
			if (c == ',')
			{
				if (!value.empty())
				{
					row.push_back((value));
				}
				value = "";
			} else
			{
				value += c;
			}
		}
		if (!value.empty())
		{
			row.push_back((value));
		}
		ingredients.push_back(row);
	}
	allIngredients.close();

	do
	{
		// my menu!!
		cout << "⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆\n";
		do
		{
			cout << "Welcome to your interactive cookbook! "
					<< "What would you like to do?\n";
			cout << "\t1. Add a recipe" << endl;
			cout << "\t2. Retrieve a recipe" << endl;
			cout << "\t3. Convert measurements" << endl;
			cout << "\t4. Let your book display one of your recipes at random!"
					<< endl;
			cout << "\t5. Scale a recipe for more/less servings" << endl;
			cout << "\t6. Finished, exit cookbook!" << endl;
			cin >> userChoice;

			// check if input is an integer
			if (cin.fail())
			{
				cout << "Invalid input. Please enter an integer.\n";
				cin.clear();
				cin.ignore(10000, '\n');
				isValidInput = false;
			}
			// check if input is a valid option
			else if (userChoice < 1 || userChoice > 6)
			{
				cout << "Invalid choice. Please enter an option between 1 and 6.\n";
				isValidInput = false;
			}
			else
			{
				isValidInput = true;
			}
		} while (!isValidInput);

		cout << "⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆⋆\n";

		switch(userChoice)
		{
		case 1: // add recipe
		{
			ofstream allQuantities;
			ofstream allIngredients;
			addRecipe(quantity, ingredients, allRecipes, allQuantities, allIngredients);
			break;
		}
		case 2: // display recipe
		{
			ifstream allRecipes;
			displayRecipe(allRecipes);
			break;
		}
		case 3: // convert between measurements
		{
			conversion();
			break;
		}
		case 4: // randomly display a recipe
		{
			ifstream allRecipes;
			randRecipe(allRecipes);
			break;
		}
		case 5: // scale a recipe to a different serving size
		{
			ifstream allRecipes;
			scaleServing(quantity, ingredients, allRecipes);
			break;
		}
		case 6:
		{
			cout << "thank u for using my interactive recipe book! hope u liked it and had fun c: see u next time\n";
			cout << "\t- saamiyah ⭐️" << endl;
			break;
		}
		default:
		{
			break;
		}
		}
	} while (userChoice != 6);

	return 0;
}
