// structure to hold the cook and prep times in a recipe
struct Times {
	double prepTime;
	double cookTime;
};
