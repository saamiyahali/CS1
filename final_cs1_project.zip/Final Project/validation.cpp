#include "validation.hpp"
#include <iostream>
#include <fstream>


// validation for making sure user's input is equal to an existing recipe name
bool validRecipe(string input, ifstream& allRecipes, bool valid)
{
    allRecipes.open("recipeNames.txt");
	allRecipes.seekg(0);

	if (valid == true)
	{
		return true;
	}
	if (!allRecipes.is_open()) // making sure file opens
    {
        cout << "Error: Unable to open file.\n";
        valid = false;
        return valid;
    }
    // get every line in the recipe names file and see if it's equal to the user's input (a recipe name)
	string line;
    while (getline(allRecipes, line))
    {
    	if (input == line)
        {
            valid = true;
            allRecipes.close();
            return valid;
        }
    }

    allRecipes.close();
    valid = false;
    return valid;
}

bool isInt(string input)
{
	// length of the c string should be the length of the input + 1 for null
	char length = input.length() + 1;
	char cstr[length];
	// copy string contents into c string
	strcpy(cstr, input.c_str());

	// if each character in  string is a number return true
	for (int i = 0; i < strlen(cstr); i++)
	{
		if (!isdigit(cstr[i]))
		{
			cout << "that wasn't a whole number :( try again\n";
			return false;
		}
	}
	return true;
}

bool isDouble(string input)
{
	// length of the c string should be the length of the input + 1 for null
	char length = input.length() + 1;
	char cstr[length];
	// copy string contents into c string
	strcpy(cstr, input.c_str());

	// if each character in string is a number or a period return true
	for (int i = 0; i < strlen(cstr); i++)
	{
		if (!isdigit(cstr[i]) && cstr[i] != '.')
		{
			cout << "that wasn't a number :( try again\n";
			return false;
		}
	}
	return true;
}
