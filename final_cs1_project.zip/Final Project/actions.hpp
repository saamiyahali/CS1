#include <vector>
#include <fstream>
#include "times.hpp"

using namespace std;
/*
 * Desc: add a recipe to the user's cookbook by creating a new text file by the recipe's name
 * Input: the 2D vectors to hold recipe ingredients and quantities, input file for recipe names file, output files for all quantities file and all ingredients file
 * Output: N/A
 */
void addRecipe(vector<vector<double>>&, vector<vector<string>>&, ifstream&, ofstream&, ofstream&);

/*
 * Desc: convert user's measurement between cups, tbsps, and tsps
 * Input: N/A
 * Output: N/A
 */
void conversion();

/*
 * Desc: scale the serving size of a recipe by retrieving all of the user's recipe's quantities from the 2D vector and multiplying them by the user's serving size
 * Input: constant 2D vectors to hold recipe ingredients and quantities, input file for recipe names file
 * Output: N/A
 */
void scaleServing(const vector<vector<double>>&, const vector<vector<string>>&, ifstream&);
